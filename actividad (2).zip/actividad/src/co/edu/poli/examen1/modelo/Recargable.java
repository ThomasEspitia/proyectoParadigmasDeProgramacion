package co.edu.poli.examen1.modelo;

/**
 * Representa una batería recargable.
 * <p>
 * Esta clase extiende la funcionalidad de {@link Bateria} para incluir el atributo
 * que define el tiempo de carga requerido para recargar la batería. Permite obtener y
 * establecer dicho tiempo, además de sobrescribir algunos métodos para adecuar el
 * comportamiento a una batería recargable.
 * </p>
 * 
 * @author 
 */
public class Recargable extends Bateria {

    /**
     * Tiempo de carga requerido para que la batería se cargue completamente.
     * Este valor puede representarse en distintos formatos (por ejemplo, "HH:mm").
     */
    private String tiempoCarga;

    /**
     * Crea una nueva instancia de Recargable utilizando los parámetros especificados.
     * <p>
     * Se inicializan los atributos heredados de {@link Bateria} y se asigna el tiempo
     * de carga correspondiente.
     * </p>
     *
     * @param marca       la marca de la batería.
     * @param voltaje     el voltaje de la batería en voltios.
     * @param capacidad   la capacidad de la batería en mAh.
     * @param serial      el número de serie de la batería.
     * @param tiempoCarga el tiempo de carga que requiere la batería recargable.
     */
    public Recargable(String marca, double voltaje, int capacidad, String serial, String tiempoCarga) {
        super(marca, voltaje, capacidad, serial);
        this.tiempoCarga = tiempoCarga;
    }

    /**
     * Obtiene el tiempo de carga configurado para la batería recargable.
     *
     * @return el tiempo de carga.
     */
    public String getTiempoCarga() {
        return tiempoCarga;
    }

    /**
     * Establece un nuevo tiempo de carga para la batería recargable.
     *
     * @param tiempoCarga el nuevo tiempo de carga.
     */
    public void setTiempoCarga(String tiempoCarga) {
        this.tiempoCarga = tiempoCarga;
    }

    /**
     * Devuelve el nombre descriptivo de la clase.
     * <p>
     * Este método sobrescribe el comportamiento heredado para adecuarse a la clase
     * Recargable.
     * </p>
     *
     * @return una cadena de texto que identifica la clase como "Recargable".
     */
    public String obtenerNombreClase() {
        return "Hola, soy de la clase: Recargable";
    }

    /**
     * Retorna una representación en forma de cadena del objeto Recargable,
     * mostrando el tiempo de carga.
     *
     * @return una cadena con la información del tiempo de carga.
     */
    @Override
    public String toString() {
        return "Recargable{" +
                "tiempoCarga='" + tiempoCarga + '\'' +
                '}';
    }
}
