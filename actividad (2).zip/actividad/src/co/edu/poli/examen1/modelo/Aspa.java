package co.edu.poli.examen1.modelo;

/**
 * Representa un aspa con atributos que definen su número de serie, tamaño y material.
 * <p>
 * La clase proporciona métodos para obtener y modificar cada uno de sus atributos,
 * permitiendo una gestión completa de la información asociada al aspa.
 * </p>
 *
 * @author 
 */
public class Aspa {

    /**
     * Número de serie único del aspa.
     */
    private String serial;

    /**
     * Tamaño del aspa.
     */
    private String size;

    /**
     * Material del que está hecho el aspa.
     */
    private String material;

    /**
     * Crea una nueva instancia de Aspa con el número de serie, tamaño y material especificados.
     *
     * @param serial   el número de serie del aspa.
     * @param size     el tamaño del aspa.
     * @param material el material del aspa.
     */
    public Aspa(String serial, String size, String material) {
        this.serial = serial;
        this.size = size;
        this.material = material;
    }

    /**
     * Obtiene el número de serie del aspa.
     *
     * @return el número de serie del aspa.
     */
    public String getSerial() {
        return serial;
    }

    /**
     * Actualiza el número de serie del aspa.
     *
     * @param serial el nuevo número de serie del aspa.
     */
    public void setSerial(String serial) {
        this.serial = serial;
    }

    /**
     * Obtiene el tamaño del aspa.
     *
     * @return el tamaño del aspa.
     */
    public String getSize() {
        return size;
    }

    /**
     * Actualiza el tamaño del aspa.
     *
     * @param size el nuevo tamaño del aspa.
     */
    public void setSize(String size) {
        this.size = size;
    }

    /**
     * Obtiene el material del aspa.
     *
     * @return el material del aspa.
     */
    public String getMaterial() {
        return material;
    }

    /**
     * Actualiza el material del aspa.
     *
     * @param material el nuevo material del aspa.
     */
    public void setMaterial(String material) {
        this.material = material;
    }

    /**
     * Devuelve una representación en cadena del objeto Aspa, mostrando todos sus atributos.
     *
     * @return una cadena de texto con los detalles del aspa.
     */
    @Override
    public String toString() {
        return "Aspa{" +
                "serial='" + serial + '\'' +
                ", size='" + size + '\'' +
                ", material='" + material + '\'' +
                '}';
    }
}
