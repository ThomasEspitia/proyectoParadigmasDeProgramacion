package co.edu.poli.examen1.modelo;

/**
 * 
 */
public class Desechable extends Bateria {

    public Desechable(String marca, double voltaje, int capacidad, String serial, int vidaUtil) {
        super(marca, voltaje, capacidad, serial);
        this.vidaUtil = vidaUtil;
    }

    public int getVidaUtil() {
        return vidaUtil;
    }

    public void setVidaUtil(int vidaUtil) {
        this.vidaUtil = vidaUtil;
    }

    /**
     * 
     */
    private int vidaUtil;

    public String obtenerNombreClase (){
        return "Hola, soy de la clase: Desechable";
    }

    @Override
    public String toString() {
        return "Desechable{" +
                "vidaUtil=" + vidaUtil +
                '}';
    }
}