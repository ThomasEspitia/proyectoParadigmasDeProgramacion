package co.edu.poli.actividad3.vista;

import co.edu.poli.examen1.modelo.*;

/**
 * Clase que contiene métodos para demostrar el polimorfismo en el manejo de objetos
 * del tipo {@link Bateria} y sus subclases.
 * <p>
 * Proporciona métodos para retornar el nombre descriptivo de la clase real de un objeto
 * de tipo {@code Bateria} y para retornar instancias específicas de batería según un parámetro numérico.
 * </p>
 */
public class metodosPolimorfismo {

    /**
     * Retorna una cadena descriptiva que indica el tipo concreto del objeto batería recibido.
     * <p>
     * Este método utiliza el nombre de la clase real (obtenido mediante {@code objeto.getClass().getName()})
     * para determinar si el objeto es una instancia de:
     * <ul>
     *   <li>{@link Bateria}</li>
     *   <li>{@link Recargable}</li>
     *   <li>{@link Desechable}</li>
     * </ul>
     * Si el objeto no coincide con ninguno de estos casos, se retorna "Rango inválido".
     * </p>
     *
     * @param objeto el objeto de tipo {@code Bateria} a evaluar.
     * @return una cadena que describe el tipo del objeto, por ejemplo, "Objeto de la clase Bateria".
     */
    public static String retornarNombreSuperclase(Bateria objeto) {
        switch (objeto.getClass().getName()) {
            case "co.edu.poli.examen1.modelo.Bateria":
                return "Objeto de la clase Bateria";
            case "co.edu.poli.examen1.modelo.Recargable":
                return "Objeto de la clase Bateria Recargable";
            case "co.edu.poli.examen1.modelo.Desechable":
                return "Objeto de la clase Bateria Desechable";
        }
        return "Rango inválido"; 
    }

    /**
     * Retorna un objeto {@code Bateria} basado en el número proporcionado.
     * <p>
     * Dependiendo del valor de {@code numero} se retornará:
     * <ul>
     *   <li>Una instancia de {@link Bateria} si {@code numero} es 1.</li>
     *   <li>Una instancia de {@link Recargable} si {@code numero} es 2.</li>
     *   <li>Una instancia de {@link Desechable} si {@code numero} es 3.</li>
     * </ul>
     * En caso de que el número no corresponda a ninguno de los casos anteriores, se retorna por defecto una instancia de {@code Bateria}.
     * </p>
     *
     * @param numero un entero que determina el tipo de objeto a retornar.
     * @return una instancia de {@code Bateria} o de sus subclases según el valor de {@code numero}.
     */
    public static Bateria retornarObjeto(int numero) {
        switch (numero) {
            case 1:
                Bateria bateria2 = new Bateria("Duracel", 800, 5000, "SDPF8JW");
                return bateria2;
            case 2:
                Recargable bateriaRecargable2 = new Recargable("Duracel", 500, 3000, "SF8420", "40 minutos");
                return bateriaRecargable2;
            case 3:
                Desechable bateriaDesechable2 = new Desechable("Duracel", 900, 2060, "4J39JS", 6);
                return bateriaDesechable2;
        }
        Bateria bateria2 = new Bateria("Duracel", 800, 5000, "SDPF8JW");
        return bateria2;
    }
}
