package co.edu.poli.actividad3.vista;

import co.edu.poli.examen1.modelo.*;
import co.edu.poli.examen1.operaciones.BateriaOperaciones;
import java.io.Serializable;
import java.util.Map;
import java.util.Scanner;
import java.util.InputMismatchException;

/**
 * Esta clase representa la interfaz principal para interactuar con el sistema de baterías.
 * <p>
 * Permite al usuario crear, consultar, actualizar, eliminar y visualizar baterías,
 * así como persistir y recuperar la información mediante serialización y deserialización.
 * La interacción se realiza a través de un menú en consola.
 * </p>
 */
public class Principal {

    /**
     * Punto de entrada de la aplicación.
     * <p>
     * Este método inicia un menú interactivo que permite realizar operaciones CRUD
     * (Crear, Consultar, Actualizar y Eliminar) sobre baterías, así como guardar y cargar
     * la base de datos en un archivo binario.
     * </p>
     *
     * @param args Argumentos de la línea de comandos (no utilizados en esta aplicación).
     */
    public static void main(String[] args) {
        // Scanner para leer entradas del usuario
        Scanner sc = new Scanner(System.in);
        // Instancia de las operaciones con baterías
        BateriaOperaciones operaciones = new BateriaOperaciones();
        int opcion = 0;

        do {
            try {
                // Mostrar menú principal
                System.out.println("\n===== MENÚ CRUD DE BATERÍAS =====");
                System.out.println("1. Crear batería");
                System.out.println("2. Consultar batería por serial");
                System.out.println("3. Actualizar batería");
                System.out.println("4. Eliminar batería");
                System.out.println("5. Ver todas las baterías");
                System.out.println("6. Serializar (Guardar en archivo)");
                System.out.println("7. Deserializar (Cargar desde archivo)");
                System.out.println("8. Salir");
                System.out.print("Seleccione una opción: ");
                
                // Capturar la opción seleccionada
                opcion = sc.nextInt();
                sc.nextLine(); // Limpiar el buffer

                // Procesar la opción seleccionada
                switch (opcion) {
                    case 1 -> {
                        // Crear batería
                        try {
                            // Solicitar datos para crear una nueva batería
                            System.out.print("Marca: ");
                            String marca = sc.nextLine();
                            System.out.print("Voltaje: ");
                            double voltaje = sc.nextDouble();
                            System.out.print("Capacidad (mAh): ");
                            int capacidad = sc.nextInt();
                            sc.nextLine(); // Limpiar el buffer
                            System.out.print("Serial: ");
                            String serial = sc.nextLine();

                            // Crear la batería y realizar la operación
                            Bateria nueva = new Bateria(marca, voltaje, capacidad, serial);
                            boolean creada = operaciones.crearBateria(nueva);
                            System.out.println(creada ? "✅ Batería creada con éxito." : "❌ Ya existe una batería con ese serial.");
                        } catch (InputMismatchException e) {
                            // Manejo de error si el usuario ingresa un dato incorrecto
                            System.out.println("⚠️ Error de entrada. Asegúrate de introducir los valores correctos.");
                            sc.nextLine(); // Limpiar el buffer
                        }
                    }
                    case 2 -> {
                        // Consultar batería por serial
                        try {
                            System.out.print("Ingrese el serial de la batería: ");
                            String serial = sc.nextLine();
                            Bateria bat = operaciones.obtenerBateria(serial);
                            if (bat != null) {
                                // Mostrar información de la batería
                                System.out.println("🔋 Marca: " + bat.getMarca());
                                System.out.println("🔋 Voltaje: " + bat.getVoltaje() + " V");
                                System.out.println("🔋 Capacidad: " + bat.getCapacidad() + " mAh");
                                System.out.println("🔋 Serial: " + bat.getSerial());
                            } else {
                                System.out.println("❌ Batería no encontrada.");
                            }
                        } catch (Exception e) {
                            // Manejo de error al consultar la batería
                            System.out.println("⚠️ Error al consultar la batería: " + e.getMessage());
                        }
                    }
                    case 3 -> {
                        // Actualizar batería
                        try {
                            System.out.print("Serial de la batería a actualizar: ");
                            String serial = sc.nextLine();
                            if (operaciones.obtenerBateria(serial) == null) {
                                System.out.println("❌ No existe una batería con ese serial.");
                                break;
                            }

                            // Solicitar nuevos datos para actualizar la batería
                            System.out.print("Nueva marca: ");
                            String marca = sc.nextLine();
                            System.out.print("Nuevo voltaje: ");
                            double voltaje = sc.nextDouble();
                            System.out.print("Nueva capacidad: ");
                            int capacidad = sc.nextInt();
                            sc.nextLine(); // Limpiar el buffer

                            // Crear la batería actualizada
                            Bateria actualizada = new Bateria(marca, voltaje, capacidad, serial);
                            operaciones.actualizarBateria(serial, actualizada);
                            System.out.println("✅ Batería actualizada.");
                        } catch (InputMismatchException e) {
                            // Manejo de error si el usuario ingresa un dato incorrecto
                            System.out.println("⚠️ Error de entrada. Asegúrate de introducir los valores correctos.");
                            sc.nextLine(); // Limpiar el buffer
                        } catch (Exception e) {
                            // Manejo de error al actualizar la batería
                            System.out.println("⚠️ Error al actualizar la batería: " + e.getMessage());
                        }
                    }
                    case 4 -> {
                        // Eliminar batería
                        try {
                            System.out.print("Serial de la batería a eliminar: ");
                            String serial = sc.nextLine();
                            boolean eliminada = operaciones.eliminarBateria(serial);
                            System.out.println(eliminada ? "✅ Batería eliminada." : "❌ No se encontró la batería.");
                        } catch (Exception e) {
                            // Manejo de error al eliminar la batería
                            System.out.println("⚠️ Error al eliminar la batería: " + e.getMessage());
                        }
                    }
                    case 5 -> {
                        // Ver todas las baterías
                        try {
                            System.out.println("📋 Lista de baterías:");
                            Map<String, Bateria> baterias = operaciones.obtenerTodas();
                            if (baterias.isEmpty()) {
                                System.out.println("⚠️ No hay baterías registradas.");
                            } else {
                                // Mostrar todas las baterías registradas
                                baterias.forEach((serial, bat) -> {
                                    System.out.println("🔋 " + serial + " - " + bat.getMarca() + " - " +
                                                       bat.getVoltaje() + "V - " + bat.getCapacidad() + "mAh");
                                });
                            }
                        } catch (Exception e) {
                            // Manejo de error al obtener todas las baterías
                            System.out.println("⚠️ Error al mostrar las baterías: " + e.getMessage());
                        }
                    }
                    case 6 -> {
                        // Serializar (guardar en archivo)
                        try {
                            operaciones.guardarEnArchivo();
                        } catch (Exception e) {
                            // Manejo de error al guardar en archivo
                            System.out.println("⚠️ Error al guardar los datos en archivo: " + e.getMessage());
                        }
                    }
                    case 7 -> {
                        // Deserializar (cargar desde archivo)
                        try {
                            operaciones.cargarDesdeArchivo();
                        } catch (Exception e) {
                            // Manejo de error al cargar desde archivo
                            System.out.println("⚠️ Error al cargar los datos desde archivo: " + e.getMessage());
                        }
                    }
                    case 8 -> {
                        // Salir del sistema
                        System.out.println("👋 Saliendo del sistema...");
                    }
                    default -> System.out.println("⚠️ Opción inválida, intenta de nuevo.");
                }
            } catch (InputMismatchException e) {
                // Manejo de error si el usuario ingresa un valor no numérico
                System.out.println("⚠️ Entrada inválida. Por favor ingresa un número válido.");
                sc.nextLine(); // Limpiar el buffer
            }
        } while (opcion != 8);

        // Cerrar el scanner al finalizar
        sc.close();
    }
}
