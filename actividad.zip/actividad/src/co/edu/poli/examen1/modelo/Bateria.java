package co.edu.poli.examen1.modelo;

import java.io.Serializable;

/**
 * Clase que representa una batería.
 * <p>
 * Esta clase implementa la interfaz {@link java.io.Serializable} para permitir que un objeto
 * de tipo Bateria pueda ser guardado y recuperado desde un archivo.
 * </p>
 * <p>
 * Contiene información sobre la marca, voltaje, capacidad y número de serie de la batería,
 * además de métodos para simular la descarga de energía.
 * </p>
 *
 * @author 
 */
public class Bateria implements Serializable {

    /**
     * Identificador de versión para la serialización de la clase.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Marca de la batería (por ejemplo, Duracell, Energizer).
     */
    private String marca;

    /**
     * Voltaje de la batería en voltios.
     */
    private double voltaje;

    /**
     * Capacidad de la batería en miliamperios hora (mAh).
     */
    private int capacidad;

    /**
     * Número de serie único de la batería.
     */
    private String serial;

    /**
     * Crea una nueva instancia de Bateria con los valores especificados.
     *
     * @param marca     la marca de la batería.
     * @param voltaje   el voltaje de la batería.
     * @param capacidad la capacidad de la batería en mAh.
     * @param serial    el número de serie de la batería.
     */
    public Bateria(String marca, double voltaje, int capacidad, String serial) {
        this.marca = marca;
        this.voltaje = voltaje;
        this.capacidad = capacidad;
        this.serial = serial;
    }

    /**
     * Obtiene la marca de la batería.
     *
     * @return la marca de la batería.
     */
    public String getMarca() {
        return marca;
    }

    /**
     * Establece la marca de la batería.
     *
     * @param marca la nueva marca de la batería.
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }

    /**
     * Obtiene el voltaje de la batería.
     *
     * @return el voltaje de la batería en voltios.
     */
    public double getVoltaje() {
        return voltaje;
    }

    /**
     * Establece el voltaje de la batería.
     *
     * @param voltaje el nuevo voltaje de la batería en voltios.
     */
    public void setVoltaje(double voltaje) {
        this.voltaje = voltaje;
    }

    /**
     * Obtiene la capacidad actual de la batería en miliamperios hora (mAh).
     *
     * @return la capacidad en mAh.
     */
    public int getCapacidad() {
        return capacidad;
    }

    /**
     * Establece la capacidad de la batería.
     *
     * @param capacidad el nuevo valor de la capacidad en mAh.
     */
    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    /**
     * Obtiene el número de serie de la batería.
     *
     * @return el número de serie.
     */
    public String getSerial() {
        return serial;
    }

    /**
     * Establece el número de serie de la batería.
     *
     * @param serial el nuevo número de serie.
     */
    public void setSerial(String serial) {
        this.serial = serial;
    }

    /**
     * Simula la descarga de energía de la batería.
     * <p>
     * Verifica si la batería tiene suficiente capacidad para satisfacer la demanda energética.
     * En caso afirmativo, reduce la capacidad en la cantidad de energía solicitada y retorna
     * un mensaje indicando la descarga y la capacidad restante.
     * </p>
     *
     * @param demandaEnergetica la cantidad de energía a descargar en Watios.
     * @param temperatura       la temperatura actual de la batería en grados Celsius.
     * @return un mensaje indicando el resultado de la descarga.
     */
    public String descargar(double demandaEnergetica, double temperatura) {
        if (capacidad >= demandaEnergetica) {
            capacidad -= (int) demandaEnergetica;
            return "Se ha descargado " + demandaEnergetica + "W a " + temperatura +
                    "°C. Capacidad restante: " + capacidad + "mAh.";
        } else {
            return "No hay suficiente carga para la demanda energética.";
        }
    }

    /**
     * Sobrecarga del método {@code descargar} que, además de la demanda energética y la temperatura,
     * evalúa el nivel de carga actual antes de realizar la descarga.
     * <p>
     * Si el nivel de carga es crítico (menor o igual a 10%), se evita la descarga y se retorna un mensaje
     * de advertencia. De lo contrario, se procede a descargar la energía siempre que la capacidad sea suficiente.
     * </p>
     *
     * @param demandaEnergetica la cantidad de energía a descargar en Watios.
     * @param temperatura       la temperatura actual de la batería en grados Celsius.
     * @param nivelCarga        el porcentaje de carga actual de la batería.
     * @return un mensaje indicando el estado de la descarga o si no es posible realizarla.
     */
    public String descargar(double demandaEnergetica, double temperatura, int nivelCarga) {
        if (nivelCarga <= 10) {
            return "Nivel de carga crítico. No se puede descargar más energía.";
        }

        if (capacidad >= demandaEnergetica) {
            capacidad -= (int) demandaEnergetica;
            return "Se ha descargado " + demandaEnergetica + "W a " + temperatura +
                    "°C con " + nivelCarga + "% de carga. Capacidad restante: " + capacidad + "mAh.";
        } else {
            return "No hay suficiente carga para la demanda energética.";
        }
    }

    /**
     * Obtiene el nombre descriptivo de la clase.
     *
     * @return una cadena de texto con el nombre de la clase.
     */
    public String obtenerNombreClase() {
        return "Hola, soy de la clase: Bateria";
    }

    /**
     * Retorna una representación en forma de cadena del objeto Bateria,
     * mostrando todos sus atributos.
     *
     * @return una cadena con la información detallada de la batería.
     */
    @Override
    public String toString() {
        return "Bateria{" +
                "marca='" + marca + '\'' +
                ", voltaje=" + voltaje +
                ", capacidad=" + capacidad +
                ", serial='" + serial + '\'' +
                '}';
    }
}
