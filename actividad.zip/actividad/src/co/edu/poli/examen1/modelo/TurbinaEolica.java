package co.edu.poli.examen1.modelo;

import java.util.Arrays;

/**
 * 
 */
public class TurbinaEolica {

    public TurbinaEolica(String size, int modelo, String marca, String material, double valor, String serial, String color, double peso, double voltajeMaximo, double corrienteMaximo, Bateria bateria, double capacidadDeLaBateria, String lugarDeFabricación, double velocidadMaximaDeGiro, int yearOfManufacture, double costo, String fechaDeSalida, String tipoDeGenerador, String certificaciones, boolean proteccionContraSobrecargas, String resistenciaAlAguaYPolvo, String vidaUtilEstimada, String accesoriosIccluidos, Aspa[] aspa) {
        this.size = size;
        this.modelo = modelo;
        this.marca = marca;
        this.material = material;
        this.valor = valor;
        this.serial = serial;
        this.color = color;
        this.peso = peso;
        this.voltajeMaximo = voltajeMaximo;
        this.corrienteMaximo = corrienteMaximo;
        this.bateria = bateria;
        this.capacidadDeLaBateria = capacidadDeLaBateria;
        this.lugarDeFabricación = lugarDeFabricación;
        this.velocidadMaximaDeGiro = velocidadMaximaDeGiro;
        this.yearOfManufacture = yearOfManufacture;
        this.costo = costo;
        this.fechaDeSalida = fechaDeSalida;
        this.tipoDeGenerador = tipoDeGenerador;
        this.certificaciones = certificaciones;
        this.proteccionContraSobrecargas = proteccionContraSobrecargas;
        this.resistenciaAlAguaYPolvo = resistenciaAlAguaYPolvo;
        this.vidaUtilEstimada = vidaUtilEstimada;
        this.accesoriosIccluidos = accesoriosIccluidos;
        this.aspa = aspa;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public int getModelo() {
        return modelo;
    }

    public void setModelo(int modelo) {
        this.modelo = modelo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getSerial() {
        return serial;
    }

    public void setSerial(String serial) {
        this.serial = serial;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public double getVoltajeMaximo() {
        return voltajeMaximo;
    }

    public void setVoltajeMaximo(double voltajeMaximo) {
        this.voltajeMaximo = voltajeMaximo;
    }

    public double getCorrienteMaximo() {
        return corrienteMaximo;
    }

    public void setCorrienteMaximo(double corrienteMaximo) {
        this.corrienteMaximo = corrienteMaximo;
    }

    public Bateria getBateria() {
        return bateria;
    }

    public void setBateria(Bateria bateria) {
        this.bateria = bateria;
    }

    public double getCapacidadDeLaBateria() {
        return capacidadDeLaBateria;
    }

    public void setCapacidadDeLaBateria(double capacidadDeLaBateria) {
        this.capacidadDeLaBateria = capacidadDeLaBateria;
    }

    public String getLugarDeFabricación() {
        return lugarDeFabricación;
    }

    public void setLugarDeFabricación(String lugarDeFabricación) {
        this.lugarDeFabricación = lugarDeFabricación;
    }

    public double getVelocidadMaximaDeGiro() {
        return velocidadMaximaDeGiro;
    }

    public void setVelocidadMaximaDeGiro(double velocidadMaximaDeGiro) {
        this.velocidadMaximaDeGiro = velocidadMaximaDeGiro;
    }

    public int getYearOfManufacture() {
        return yearOfManufacture;
    }

    public void setYearOfManufacture(int yearOfManufacture) {
        this.yearOfManufacture = yearOfManufacture;
    }

    public double getCosto() {
        return costo;
    }

    public void setCosto(double costo) {
        this.costo = costo;
    }

    public String getFechaDeSalida() {
        return fechaDeSalida;
    }

    public void setFechaDeSalida(String fechaDeSalida) {
        this.fechaDeSalida = fechaDeSalida;
    }

    public String getTipoDeGenerador() {
        return tipoDeGenerador;
    }

    public void setTipoDeGenerador(String tipoDeGenerador) {
        this.tipoDeGenerador = tipoDeGenerador;
    }

    public String getCertificaciones() {
        return certificaciones;
    }

    public void setCertificaciones(String certificaciones) {
        this.certificaciones = certificaciones;
    }

    public boolean isProteccionContraSobrecargas() {
        return proteccionContraSobrecargas;
    }

    public void setProteccionContraSobrecargas(boolean proteccionContraSobrecargas) {
        this.proteccionContraSobrecargas = proteccionContraSobrecargas;
    }

    public String getResistenciaAlAguaYPolvo() {
        return resistenciaAlAguaYPolvo;
    }

    public void setResistenciaAlAguaYPolvo(String resistenciaAlAguaYPolvo) {
        this.resistenciaAlAguaYPolvo = resistenciaAlAguaYPolvo;
    }

    public String getVidaUtilEstimada() {
        return vidaUtilEstimada;
    }

    public void setVidaUtilEstimada(String vidaUtilEstimada) {
        this.vidaUtilEstimada = vidaUtilEstimada;
    }

    public String getAccesoriosIccluidos() {
        return accesoriosIccluidos;
    }

    public void setAccesoriosIccluidos(String accesoriosIccluidos) {
        this.accesoriosIccluidos = accesoriosIccluidos;
    }

    public Aspa[] getAspa() {
        return aspa;
    }

    public void setAspa(Aspa[] aspa) {
        this.aspa = aspa;
    }

    /**
     * 
     */
    private String size;

    /**
     * 
     */
    private int modelo;

    /**
     * 
     */
    private String marca;

    /**
     * 
     */
    private String material;

    /**
     * 
     */
    private double valor;

    /**
     * 
     */
    private String serial;

    /**
     * 
     */
    private String color;

    /**
     * 
     */
    private double peso;

    /**
     * 
     */
    private double voltajeMaximo;

    /**
     * 
     */
    private double corrienteMaximo;

    /**
     * 
     */
    private Bateria bateria;

    /**
     * 
     */
    private double capacidadDeLaBateria;

    /**
     * 
     */
    private String lugarDeFabricación;

    /**
     * 
     */
    private double velocidadMaximaDeGiro;

    /**
     * 
     */
    private int yearOfManufacture;

    /**
     * 
     */
    private double costo;

    /**
     * 
     */
    private String fechaDeSalida;

    /**
     * 
     */
    private String tipoDeGenerador;

    /**
     * 
     */
    private String certificaciones;

    /**
     * 
     */
    private boolean proteccionContraSobrecargas;

    /**
     * 
     */
    private String resistenciaAlAguaYPolvo;

    /**
     * 
     */
    private String vidaUtilEstimada;

    /**
     * 
     */
    private String accesoriosIccluidos;

    /**
     * 
     */
    private Aspa [ ] aspa;

    /**
     * 
     */
    /**
     * @param velocidadViento 
     * @return
     */
    public boolean activarFrenos(Float velocidadViento) {
        if (velocidadViento > 25.0) { // Umbral de seguridad para activar frenos
            System.out.println("Frenos activados: Velocidad del viento peligrosa (" + velocidadViento + " m/s)");
            return true;
        } else {
            System.out.println("Frenos desactivados: Velocidad del viento segura (" + velocidadViento + " m/s)");
            return false;
        }
    }

    /**
     * @param currentYear 
     * @return
     */
    public int calcularEdadAcual(int currentYear) {
        int edad = currentYear - yearOfManufacture;
        if (edad < 0) {
            System.out.println("Error: Año de fabricación mayor al año actual.");
            return 0;
        }
        return edad;
    }

    @Override
    public String toString() {
        return "TurbinaEolica{" +
                "size='" + size + '\'' +
                ", modelo=" + modelo +
                ", marca='" + marca + '\'' +
                ", material='" + material + '\'' +
                ", valor=" + valor +
                ", serial='" + serial + '\'' +
                ", color='" + color + '\'' +
                ", peso=" + peso +
                ", voltajeMaximo=" + voltajeMaximo +
                ", corrienteMaximo=" + corrienteMaximo +
                ", bateria=" + bateria +
                ", capacidadDeLaBateria=" + capacidadDeLaBateria +
                ", lugarDeFabricación='" + lugarDeFabricación + '\'' +
                ", velocidadMaximaDeGiro=" + velocidadMaximaDeGiro +
                ", yearOfManufacture=" + yearOfManufacture +
                ", costo=" + costo +
                ", fechaDeSalida='" + fechaDeSalida + '\'' +
                ", tipoDeGenerador='" + tipoDeGenerador + '\'' +
                ", certificaciones='" + certificaciones + '\'' +
                ", proteccionContraSobrecargas=" + proteccionContraSobrecargas +
                ", resistenciaAlAguaYPolvo='" + resistenciaAlAguaYPolvo + '\'' +
                ", vidaUtilEstimada='" + vidaUtilEstimada + '\'' +
                ", accesoriosIccluidos='" + accesoriosIccluidos + '\'' +
                ", aspa=" + Arrays.toString(aspa) +
                '}';
    }
}