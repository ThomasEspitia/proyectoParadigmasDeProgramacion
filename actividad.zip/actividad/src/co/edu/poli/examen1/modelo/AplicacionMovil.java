package co.edu.poli.examen1.modelo;

/**
 * Representa una aplicación móvil.
 * <p>
 * Esta clase es final, por lo que no puede heredarse. Contiene información sobre el nombre
 * y el peso de la aplicación, y proporciona métodos para obtener y actualizar el peso,
 * así como para mostrar los detalles de la aplicación.
 * </p>
 *
 * @author 
 */
final class AplicacionMovil { // CLASE QUE NO SE PUEDE HEREDAR

    /**
     * El nombre de la aplicación. Este atributo es final, por lo que no puede ser modificado
     * una vez asignado en el constructor.
     */
    private final String nombre; // ATRIBUTO QUE NO SE PUEDE CAMBIAR

    /**
     * El peso de la aplicación expresado en megabytes.
     */
    private double peso;
    
    /**
     * Crea una nueva instancia de AplicacionMovil con el nombre y el peso especificados.
     *
     * @param nombre El nombre de la aplicación.
     * @param peso   El peso de la aplicación en MB.
     */
    public AplicacionMovil(String nombre, double peso) {
        this.nombre = nombre;
        this.peso = peso;
    }

    /**
     * Obtiene el nombre de la aplicación.
     *
     * @return el nombre de la aplicación.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Obtiene el peso de la aplicación en megabytes.
     *
     * @return el peso de la aplicación en MB.
     */
    public double getPeso() {
        return peso;
    }

    /**
     * Actualiza el peso de la aplicación.
     *
     * @param peso El nuevo peso de la aplicación en MB.
     */
    public void setPeso(double peso) {
        this.peso = peso;
    }
    
    /**
     * Muestra por consola los detalles de la aplicación, incluyendo el nombre y el peso.
     * <p>
     * Este método es final, por lo que no se puede sobrescribir en subclases.
     * </p>
     */
    public final void mostrarDetalles() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Peso: " + peso + "MB");
    }

    /**
     * Retorna una representación en cadena de la aplicación.
     *
     * @return una cadena que contiene el nombre y el peso de la aplicación.
     */
    @Override
    public String toString() {
        return "AplicacionMovil{" +
                "nombre='" + nombre + '\'' +
                ", peso=" + peso +
                '}';
    }
}
