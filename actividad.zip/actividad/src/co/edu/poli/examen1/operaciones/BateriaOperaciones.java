package co.edu.poli.examen1.operaciones;

import java.io.*;
import co.edu.poli.examen1.modelo.Bateria;
import java.util.HashMap;
import java.util.Map;

/**
 * Esta clase se encarga de las operaciones CRUD sobre las baterías,
 * como guardar, cargar, crear, actualizar, eliminar y consultar baterías.
 * <p>
 * Las baterías se almacenan en un archivo binario para garantizar la persistencia
 * de la información, simulando una base de datos en memoria con un {@code Map}.
 * </p>
 */
public class BateriaOperaciones {

    /**
     * Mapa que simula una base de datos en memoria, donde la clave es el serial de la batería.
     */
    private Map<String, Bateria> baseDatos = new HashMap<>();

    /**
     * Ruta del archivo donde se almacenan las baterías serializadas.
     */
    private final String archivo = "baterias.bin";

    /**
     * Guarda la base de datos de baterías en un archivo binario.
     * <p>
     * Si ocurre algún error durante el proceso de escritura, se captura y se muestra el mensaje
     * de error correspondiente.
     * </p>
     */
    public void guardarEnArchivo() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(archivo))) {
            // Se escribe el mapa de baterías en el archivo
            oos.writeObject(baseDatos);
            System.out.println("💾 Datos guardados en archivo.");
        } catch (FileNotFoundException e) {
            // Manejo específico para archivo no encontrado
            System.out.println("⚠️ El archivo no se encuentra: " + e.getMessage());
            e.printStackTrace();
        } catch (IOException e) {
            // Manejo de errores generales de entrada/salida
            System.out.println("⚠️ Error de entrada/salida al guardar: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            // Manejo de cualquier otro tipo de error no esperado
            System.out.println("⚠️ Error desconocido al guardar en archivo: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Carga la base de datos de baterías desde un archivo binario.
     * <p>
     * Si el archivo no existe, se notifica que no hay datos y se inicia una base nueva.
     * </p>
     */
    @SuppressWarnings("unchecked")
    public void cargarDesdeArchivo() {
        File f = new File(archivo);
        // Verifica si el archivo no existe
        if (!f.exists()) {
            System.out.println("ℹ️ No hay archivo de datos, se inicia una base nueva.");
            return;
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f))) {
            // Se lee el mapa de baterías desde el archivo
            baseDatos = (Map<String, Bateria>) ois.readObject();
            System.out.println("✅ Base de datos cargada con éxito.");
        } catch (FileNotFoundException e) {
            // Manejo del error cuando el archivo no se encuentra
            System.out.println("⚠️ El archivo no fue encontrado: " + e.getMessage());
            e.printStackTrace();
        } catch (IOException e) {
            // Manejo de errores de entrada/salida
            System.out.println("⚠️ Error al leer el archivo: " + e.getMessage());
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            // Manejo de errores relacionados con la clase no encontrada durante la deserialización
            System.out.println("⚠️ Error de clase no encontrada al cargar: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            // Manejo de cualquier otro tipo de error no esperado
            System.out.println("⚠️ Error desconocido al cargar archivo: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Crea una nueva batería y la agrega a la base de datos.
     * <p>
     * Se verifica que la batería no sea nula y que no exista ya una con el mismo serial.
     * </p>
     *
     * @param bateria La batería que se desea crear.
     * @return {@code true} si la batería fue creada con éxito; {@code false} si ya existe
     *         una batería con el mismo serial.
     * @throws IllegalArgumentException Si la batería es nula.
     */
    public boolean crearBateria(Bateria bateria) {
        if (bateria == null) {
            throw new IllegalArgumentException("⚠️ La batería no puede ser nula.");
        }
        // Verifica si ya existe una batería con el mismo serial
        if (baseDatos.containsKey(bateria.getSerial())) {
            System.out.println("⚠️ Ya existe una batería con el serial: " + bateria.getSerial());
            return false;
        }
        baseDatos.put(bateria.getSerial(), bateria);
        System.out.println("✅ Batería creada con éxito.");
        return true;
    }

    /**
     * Obtiene una batería de la base de datos por su serial.
     *
     * @param serial El serial de la batería que se desea obtener.
     * @return La batería asociada al serial, o {@code null} si no existe.
     * @throws IllegalArgumentException Si el serial es nulo o vacío.
     */
    public Bateria obtenerBateria(String serial) {
        if (serial == null || serial.trim().isEmpty()) {
            throw new IllegalArgumentException("⚠️ El serial no puede ser nulo o vacío.");
        }
        Bateria bateria = baseDatos.get(serial);
        if (bateria == null) {
            System.out.println("⚠️ No se encontró la batería con el serial: " + serial);
        }
        return bateria;
    }

    /**
     * Actualiza una batería existente en la base de datos.
     * <p>
     * Se reemplaza la batería asociada al serial dado por la nueva batería proporcionada.
     * </p>
     *
     * @param serial       El serial de la batería a actualizar.
     * @param nuevaBateria La nueva batería con los datos actualizados.
     * @return {@code true} si la batería fue actualizada con éxito; {@code false} si no existe
     *         una batería con ese serial.
     * @throws IllegalArgumentException Si el serial o la nueva batería son nulos o están vacíos.
     */
    public boolean actualizarBateria(String serial, Bateria nuevaBateria) {
        if (serial == null || serial.trim().isEmpty()) {
            throw new IllegalArgumentException("⚠️ El serial no puede ser nulo o vacío.");
        }
        if (nuevaBateria == null) {
            throw new IllegalArgumentException("⚠️ La nueva batería no puede ser nula.");
        }
        if (!baseDatos.containsKey(serial)) {
            System.out.println("⚠️ No existe una batería con el serial: " + serial);
            return false;
        }
        baseDatos.put(serial, nuevaBateria);
        System.out.println("✅ Batería actualizada con éxito.");
        return true;
    }

    /**
     * Elimina una batería de la base de datos.
     *
     * @param serial El serial de la batería a eliminar.
     * @return {@code true} si la batería fue eliminada con éxito; {@code false} si no se encontró la batería.
     * @throws IllegalArgumentException Si el serial es nulo o vacío.
     */
    public boolean eliminarBateria(String serial) {
        if (serial == null || serial.trim().isEmpty()) {
            throw new IllegalArgumentException("⚠️ El serial no puede ser nulo o vacío.");
        }
        if (!baseDatos.containsKey(serial)) {
            System.out.println("⚠️ No existe una batería con el serial: " + serial);
            return false;
        }
        baseDatos.remove(serial);
        System.out.println("✅ Batería eliminada con éxito.");
        return true;
    }

    /**
     * Obtiene todas las baterías almacenadas en la base de datos.
     *
     * @return El mapa completo que contiene todas las baterías, donde la clave es el serial.
     */
    public Map<String, Bateria> obtenerTodas() {
        if (baseDatos.isEmpty()) {
            System.out.println("⚠️ No hay baterías en la base de datos.");
        }
        return baseDatos;
    }
}
