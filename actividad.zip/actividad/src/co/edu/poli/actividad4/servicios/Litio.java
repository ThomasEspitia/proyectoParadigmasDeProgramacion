package co.edu.poli.actividad4.servicios;

import co.edu.poli.examen1.modelo.Desechable;

/**
 * 
 */
public class Litio extends Desechable {

    public Litio(String marca, double voltaje, int capacidad, String serial, int vidaUtil) {
        super(marca, voltaje, capacidad, serial, vidaUtil);
    }

    public String getTipoCelda() {
        return tipoCelda;
    }

    public void setTipoCelda(String tipoCelda) {
        this.tipoCelda = tipoCelda;
    }

    /**
     * 
     */
    private String tipoCelda;

    @Override
    public String toString() {
        return "Litio{" +
                "tipoCelda='" + tipoCelda + '\'' +
                '}';
    }
}